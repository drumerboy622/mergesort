Author: Matthew Solbrack 
Email: solbracm@oregonstate.edu
Subject: Homework 1 / Question 3 "Merge Sort and insertion Sort Programs"

To run mergesort and insertsort add 'data.txt' file. Then, enter "make" in the command line. For the insertTime and mergeTime enter "make timefiles" into the command line. To clear the files the program makes, enter "make clean" into the command line. 


